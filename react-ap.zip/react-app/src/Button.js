const Button = ({ value }) => {
  return <div>{value}</div>;
};
export default Button;
