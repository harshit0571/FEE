import React from "react";

const Fotter = () => {
  return (
    <footer>
      <div class="foot-row1">
        <div class="fcolumn1">
          <h2>Dicet Tv</h2>
          <h4>CUSTOMER SERVICE</h4>
          <p>
            There are many variant ions of passages of Lorem ipsum available,
            but the majority have suffered alteration in some form, by
          </p>
        </div>
        <div class="col-lg-2 fcolumn2">
          <h4>LET US HELP YOU</h4>
          <p>
            There are many variant ions of passages of Lorem ipsum available,
            but the majority have suffered alteration in some form, by
          </p>
        </div>
        <div class="col-lg-2 fcolumn3">
          <h4>INFORMATION</h4>
          <ul class="list">
            <li>
              <a href=""></a>About Us
            </li>
            <li>
              <a href=""></a>Careers
            </li>
            <li>
              <a href=""></a>Sell on shopee
            </li>
            <li>
              <a href=""></a>Press & News
            </li>
            <li>
              <a href=""></a>Competitions
            </li>
            <li>
              <a href=""></a>Terms & Conditions
            </li>
          </ul>
        </div>
        <div class="col-lg-2 fcolumn4">
          <h4>OUR SHOP</h4>
          <p>
            There are many variant ions of passages of Lorem ipsum available,
            but the majority have suffered alteration in some form, by
          </p>

          <div class="social-logo">
            <i class="fa fa-facebook-f" aria-hidden="true"></i>
            <i class="fa fa-twitter" aria-hidden="true"></i>
            <i class="fa fa-instagram" aria-hidden="true"></i>
            <i class="fa fa-linkedin" aria-hidden="true"></i>
          </div>
        </div>
        <div class="col-lg-1">&nbsp;</div>
      </div>
      <div class="foot-row2">
        © 2019 All Rights Reserved. Developed by Gopal Jana
      </div>
    </footer>
  );
};

export default Fotter;
